package Modelo;

import java.util.ArrayList;

public class Student {

	private String picture;
	private String name;
	private String lastname;
	private int phoneNumber;
	private String email;
	private int age;
	private ArrayList<Subject> subjects;

	public Student(String picture, String name, String lastname, int phoneNumber, String email, int age,
			ArrayList<Subject> subjects) {
		super();
		this.picture = picture;
		this.name = name;
		this.lastname = lastname;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.age = age;
		this.subjects = subjects;
	}


	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public int getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public ArrayList<Subject> getSubjects() {
		return subjects;
	}

	public void setSubjects(ArrayList<Subject> subjects) {
		this.subjects = subjects;
	}

	public void addSubject(Subject sub){
		for(int i=0;i<subjects.size();i++){
			if(!subjects.get(i).equals(sub)){
				subjects.add(sub);
			}
		}
	}

	public void removeSubject(Subject sub){
		for(int i=0; i<subjects.size(); i++){
			if(sub.equals(subjects.get(i))){
				subjects.get(i).equals(null);
			}
		}
	}

	public ArrayList<Integer> report(){
		ArrayList<Integer> report=null;

		return report;
	}


}
