package Modelo;

public class Agenda {

}
